package iamutkarshtiwari.github.io.ananas.editimage;

public final class ModuleConfig {
    public static final int INDEX_MAIN = 0;
    public static final int INDEX_STICKER = 1;
    public static final int INDEX_FILTER = 2;
    public static final int INDEX_CROP = 3;
    public static final int INDEX_ROTATE = 4;
    public static final int INDEX_ADDTEXT = 5;
    public static final int INDEX_PAINT = 6;
    public static final int INDEX_BEAUTY = 7;
    public static final int INDEX_BRIGHTNESS = 8;
    public static final int INDEX_CONTRAST = 9;
}
