package iamutkarshtiwari.github.io.ananas.editimage.gesture;

public class TransformInfo {
    float deltaX;
    float deltaY;
    float deltaScale;
    float deltaAngle;
    float pivotX;
    float pivotY;
    float minimumScale;
    float maximumScale;
}
