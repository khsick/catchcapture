package iamutkarshtiwari.github.io.ananas.editimage.interfaces

interface OnColorSelected {
    fun onColorSelected(position: Int, color: Int)
    fun onMoreSelected(position: Int)
}