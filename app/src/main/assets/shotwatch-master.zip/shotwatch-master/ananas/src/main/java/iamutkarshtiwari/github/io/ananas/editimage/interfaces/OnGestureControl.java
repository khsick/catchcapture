package iamutkarshtiwari.github.io.ananas.editimage.interfaces;

public interface OnGestureControl {
    void onClick();

    void onDown();

    void onLongClick();
}
