package iamutkarshtiwari.github.io.ananas.editimage.interfaces

interface OnLoadingDialogListener {
    fun showLoadingDialog()
    fun dismissLoadingDialog()
}
