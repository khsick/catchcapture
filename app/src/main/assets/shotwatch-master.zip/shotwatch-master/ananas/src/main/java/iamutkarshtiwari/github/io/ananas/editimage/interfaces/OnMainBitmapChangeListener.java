package iamutkarshtiwari.github.io.ananas.editimage.interfaces;

public interface OnMainBitmapChangeListener {
    void onMainBitmapChange();
}
