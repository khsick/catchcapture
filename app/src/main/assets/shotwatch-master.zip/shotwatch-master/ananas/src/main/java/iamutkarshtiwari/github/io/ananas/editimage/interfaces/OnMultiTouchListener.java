package iamutkarshtiwari.github.io.ananas.editimage.interfaces;

import android.view.View;

public interface OnMultiTouchListener {
    void onRemoveViewListener(View removedView);
}
