package iamutkarshtiwari.github.io.ananas.editimage.interfaces;

public interface OnTextEditorListener {
    void onDone(String inputText, int colorCode);
}

