package iamutkarshtiwari.github.io.ananas.editimage.view;

public class Constants {
    public static final int STICKER_BTN_HALF_SIZE = 30;
}
