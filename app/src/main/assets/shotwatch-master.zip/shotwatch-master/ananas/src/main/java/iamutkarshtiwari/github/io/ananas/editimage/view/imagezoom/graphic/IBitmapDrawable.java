package iamutkarshtiwari.github.io.ananas.editimage.view.imagezoom.graphic;

import android.graphics.Bitmap;

public interface IBitmapDrawable {

	Bitmap getBitmap();
}
