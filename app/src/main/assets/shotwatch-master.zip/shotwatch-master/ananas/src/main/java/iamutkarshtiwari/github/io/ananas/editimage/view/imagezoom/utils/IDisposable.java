package iamutkarshtiwari.github.io.ananas.editimage.view.imagezoom.utils;

public interface IDisposable {
	void dispose();
}
