package com.abangfadli.shotwatchapp.filters

interface FilterListener {

}
