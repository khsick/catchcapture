package com.abangfadli.shotwatchapp.filters

import com.abangfadli.shotwatchapp.View.ImageEditTest

class FilterViewAdapter(imageEditTest: ImageEditTest) {

}
