package com.abangfadli.shotwatchapp.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import android.content.Context
import android.os.Build
import android.widget.Toast
import com.abangfadli.shotwatchapp.broadcastreceive.CaputreReceiver
import com.abangfadli.shotwatchapp.View.ImageEditTest
import com.abangfadli.shotwatchapp.R
import com.abangfadli.shotwatchapp.View.MainActivity
import com.akexorcist.screenshotdetection.ScreenshotDetectionDelegate
import java.util.*


class CaputreService : Service(), ScreenshotDetectionDelegate.ScreenshotDetectionListener    {

    private val screenshotDetectionDelegate = ScreenshotDetectionDelegate(MainActivity.mContext as Activity?, this)

    override fun onScreenCapturedWithDeniedPermission() {
        Toast.makeText(applicationContext,"onScreenCapturedWithDeniedPermission",Toast.LENGTH_LONG).show()

    }


    override fun onScreenCaptured(path: String?) {


        var intent = Intent(this, ImageEditTest::class.java)

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtra("url_path",path)
        startActivity(intent)
        Toast.makeText(applicationContext,"path : $path",Toast.LENGTH_LONG).show()

    }


    companion object {
        var serviceIntent: Intent? = null
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        Log.i("test","service 시작")
        serviceIntent = intent
        initializeNotification()
        //Toast.makeText(applicationContext,"service 시작",Toast.LENGTH_LONG).show()
        screenshotDetectionDelegate.startScreenshotDetection()


        return START_STICKY;

    }


    fun initializeNotification() {

        var builder = NotificationCompat.Builder(this, "1")
        builder.setSmallIcon(R.mipmap.ic_launcher)

        var style = NotificationCompat.BigTextStyle()
        style.bigText("설정을 보려면 누르세요")
        style.setBigContentTitle(null)
        style.setSummaryText("서비스 동작중")

        builder.setContentText("텍스트")
        builder.setContentTitle("제목")
        builder.setOngoing(true)

        builder.setStyle(style)
        builder.setWhen(0)
        builder.setShowWhen(false)

        var notificationIntent = Intent(this, MainActivity::class.java)
        var pendingIntent = PendingIntent.getActivity(this,0,notificationIntent,0)
        builder.setContentIntent(pendingIntent)

        var manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.O){
            manager.createNotificationChannel(NotificationChannel("1","Capture_service",NotificationManager.IMPORTANCE_NONE))
            var notification =builder.build()
            startForeground(1,notification)
        }


    }


    override fun onDestroy() {
        super.onDestroy()
        var intent = Intent(this, CaputreReceiver::class.java)
        var sender = PendingIntent.getBroadcast(this, 0, intent, 0)
        val calendar = Calendar.getInstance()
        calendar.setTimeInMillis(System.currentTimeMillis() )
        calendar.add(Calendar.SECOND, 3)
        val alarmManager : AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), sender)


    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        var intent = Intent(this, CaputreReceiver::class.java)
        var sender = PendingIntent.getBroadcast(this, 0, intent, 0)
        val calendar = Calendar.getInstance()
        calendar.setTimeInMillis(System.currentTimeMillis() )
        calendar.add(Calendar.SECOND, 3)
        val alarmManager : AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), sender)

    }

    override fun onBind(p0: Intent?): IBinder? {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}


